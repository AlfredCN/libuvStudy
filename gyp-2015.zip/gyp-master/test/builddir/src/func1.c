#include <stdio.h>

void func1(void)
{
  printf("Hello from func1.c\n");
}

#!/bin/bash

tr a-z A-Z < "${1}" > "${2}"

typedef int MyInt;

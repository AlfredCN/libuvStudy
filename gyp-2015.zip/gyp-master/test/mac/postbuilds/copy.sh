#!/bin/bash

cp "$@"

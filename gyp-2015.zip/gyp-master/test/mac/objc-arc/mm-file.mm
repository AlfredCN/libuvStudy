#if !__has_feature(objc_arc)
#error "ObjC++ files with CLANG_ENABLE_OBJC_ARC should be ARC'd!"
#endif

void mm_fun() {}
